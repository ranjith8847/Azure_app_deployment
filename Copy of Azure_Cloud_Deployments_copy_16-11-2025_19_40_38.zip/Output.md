**1. ResourceGroup**


**resource group name**: try to give name for easier identification

**region:** east asia

**2. Flexible Server (****Azure Database for PostgreSQL - Flexible Servers)**

Why flexible?

*standard replica is there

has the High Availability and Disaster Recovery

![Enter image alt description](Images/tJJ_Image_1.png)
![Enter image alt description](Images/Iqd_Image_2.png)
![Enter image alt description](Images/THt_Image_3.png)

![Enter image alt description](Images/D6H_Image_4.png)
**CREATE SERVER WITHOUT FIREWALL RULES**

![Enter image alt description](Images/3ku_Image_5.png)

**Copy server name from the deployed postgress server**

![Enter image alt description](Images/EFj_Image_6.png)

- After deployment download and install dbvear from [https://dbeaver.io/download/](https://dbeaver.io/download/)

![Enter image alt description](Images/Btz_Image_7.png)

![Enter image alt description](Images/mTr_Image_8.png)

- Now you can click on testconnection and it willconnect to your postgress mysql database.

![Enter image alt description](Images/ji5_Image_9.png)
![Enter image alt description](Images/5Sb_Image_10.png)



**4. APP SERVICE**

![Enter image alt description](Images/jtG_Image_11.png)

No Database needed for now

![Enter image alt description](Images/jg5_Image_12.png)

For connecting repo for CD (as we are just learning deployments no need for repo connection)

![Enter image alt description](Images/Spm_Image_13.png)

![Enter image alt description](Images/PNQ_Image_14.png)

![Enter image alt description](Images/IIO_Image_15.png)

**5. FRONT DOOR**

![Enter image alt description](Images/jnk_Image_16.png)

![Enter image alt description](Images/FZ2_Image_17.png)

In configuration, click “+” on frontends and domains

Give a desired name and create

![Enter image alt description](Images/TMC_Image_18.png)

Click “+” on Backend Pools

![Enter image alt description](Images/uDO_Image_19.png)

Now we should add a backend (appservice)

Click on “Add a backend” in  “Backends”

***Create the backends for both appservice-primary and appservice-secondary***

![Enter image alt description](Images/e4o_Image_20.png)

***Create the backends for both appservice-primary and appservice-secondary***

![Enter image alt description](Images/69d_Image_21.png)

Click “+” on routes and give a route name and you can deploy Azure FrontDoor

**6. Create Azure Self-Hosted Agent-Pool**

The build pipelines which we create will run on the AgentPool (which is nothing but a VM)

So we need to set up the VM for running our build pipelines

If you have deleted the previously created VM (which is a good practice because we are broke XD) go ahead and create a VM by referring to above process

After creating the VM, ssh into the VM

*Ssh is nothing but accessing the VM(remote resource) from your local machine.*

*Before that make sure you have downloaded the private_key*

*And have the public ip of the VM in hand (it can be found in VM overview details)*

![Enter image alt description](Images/cfv_Image_22.png)

Open cmd,

Enter the command “**ssh -i <private_key_path> azureuser@<public_ip_of_vm>**”

After running the command type “yes” if it asks for input

![Enter image alt description](Images/YGM_Image_23.png)

After *ssh*ing into the VM we should configure it as an agentpool.

For that go to project, (in my case it is [https://dev.azure.com/ranjithchowdary2001/baasic-reactjs](https://dev.azure.com/ranjithchowdary2001/baasic-reactjs))

Go to **Project settings -> Agent Pools -> click “Add pool”**

![Enter image alt description](Images/RMx_Image_24.png)

Click on **Create**

Go to the terminal in which you have established an ssh connection to the VM

Run the command “**mkdir myagent && cd myagent**”

![Enter image alt description](Images/lku_Image_25.png)

Run the command “wget [https://vstsagentpackage.azureedge.net/agent/2.214.1/vsts-agent-linux-x64-2.214.1.tar.gz](https://vstsagentpackage.azureedge.net/agent/2.214.1/vsts-agent-linux-x64-2.214.1.tar.gz)” to download the requirements


![Enter image alt description](Images/Mw1_Image_26.png)

Run the command “tar zxvf vsts-agent-linux-x64-2.214.1.tar.gz” to configure the agent

![Enter image alt description](Images/PvW_Image_27.png)

If you do “**ls -al**” you chould see the shell scripts “**config.sh**” and “**env.sh**”

![Enter image alt description](Images/Hlq_Image_28.png)

Run the shell script using “**./config.sh**”

If you are getting an error as

![Enter image alt description](Images/TO1_Image_29.png)

Run the command “**export DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1**”

And then again run the “**./config.sh**”

![Enter image alt description](Images/F2B_Image_30.png)

Accept the license agreement by typing Y and hit enter

It asks for the server URL, enter it as “**[https://dev.azure.com/](https://dev.azure.com/yourorganization)****[yourorganization](https://dev.azure.com/yourorganization)**”

In my case it is

![Enter image alt description](Images/xfT_Image_31.png)

Then it asks for authentication type as PAT(personal access token), hit enter

![Enter image alt description](Images/8WX_Image_32.png)

For getting the personal access token,

Click on “**ser settings**” -> “**Personal Access Token**”

![Enter image alt description](Images/h2k_Image_33.png)

Click on “**New Token**”

Click on “**Show all scopes**” at the bottom

Find the **Agent Pools **and enable** “Read and Manage”**

Click on create

![Enter image alt description](Images/8oK_Image_34.png)

***Make sure to copy the token***

![Enter image alt description](Images/5R9_Image_35.png)

Next we need to configure the self hosted agent

Run “**sudo ./svc.sh install &**”

![Enter image alt description](Images/Kfj_Image_36.png)

Now run the service

Execute the command “**./runsvc.sh**”

![Enter image alt description](Images/Wca_Image_37.png)

Now the self-hosted agent is set for running the build pipelines

**7. BUILD PIPELINES**

Go to ado and into the project repo \
Go to **pipelines -> create pipeline (or) new pipeline -> Use the classic editor**

![Enter image alt description](Images/TCU_Image_38.png)

Start with the “**Empty job**”

![Enter image alt description](Images/k8X_Image_39.png)
Click “+” on “Agent job1”

Search and select Command line and click on “Add”

![Enter image alt description](Images/lNC_Image_40.png)


![Enter image alt description](Images/5SL_Image_41.png)

After this, again click “+” on Agent job 1

Search for “Publish build artifacts” and click Add

![Enter image alt description](Images/988_Image_42.png)

![Enter image alt description](Images/xSf_Image_43.png)

And finally click on the pipeline on the top and select the agent pool (which is the one we created in the previous step)

![Enter image alt description](Images/Avc_Image_44.png)

Click on “**save and queue**” and then click on “**Run**”

Now you can see your build pipeline getting executed

**Note:**

**In this demo as we are building the node js application, the self-hosted VM should have nodejs and npm installed**

**It can be installed by sshing into the VM and through the terminal run,**

**“sudo apt update”**

**“sudo apt install nodejs”**

**“sudo apt install npm”**

**8. RELEASE PIPELINES**

Under **Pipelines **go to **Releases** in ADO and click **new pipeline **and select **empty job** 

Click on **add an artifact** and select the source pipeline as the previously created build pipeline

And click on **Add**

![Enter image alt description](Images/FIt_Image_45.png)

Click on **job, task**

![Enter image alt description](Images/CYg_Image_46.png)

**Click on “+” **and add Azure App Service deploy

![Enter image alt description](Images/S9X_Image_47.png)

Select the Azure subscription and if you need to authorize, go ahead and do it
